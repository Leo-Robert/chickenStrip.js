# chickenStripsjs :chicken:

## :fire: A framework that does one thing very well! :fire: 
